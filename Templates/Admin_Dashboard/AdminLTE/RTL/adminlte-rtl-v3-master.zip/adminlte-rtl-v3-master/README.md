<h2>Introduction</h2>
<p><strong><a href="https://mratwan.github.io/rtl-AdminLTE3/">rtl-AdminLTE3</a></strong> is a beautiful admin template using <a href="https://getbootstrap.com/">Bootstrap4</a></p>

<h2>Installation</h2>

<h4>download</h4>

<p>or copy to your computer</p>

```
git clone https://github.com/mratwan/rtl-AdminLTE3.git
```

<h2>documentations</h2>
<p>coming soon...</p>


<h2>browsers support</h2>
<ul>
  <li>IE 10+</li>
  <li>Firefox (latest)</li>
  <li>Chrome (latest)</li>
  <li>Safari (latest)</li>
  <li>Opera (latest)</li>
</ul>